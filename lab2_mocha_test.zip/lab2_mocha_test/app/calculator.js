// app/calculator.js
export const add = function(i, j) {
  return i + j;
};

export const mul = function(i, j) {
  return i * j;
};

export const div = function(i, j) {
  return i / j;
};

export const sub = function(i, j) {
  return i - j;
};
